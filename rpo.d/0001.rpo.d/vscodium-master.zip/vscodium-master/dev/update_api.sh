#!/usr/bin/env bash

set -e

export VSCODE_QUALITY="stable"

while getopts ":i" opt; do
  case "$opt" in
    i)
      export VSCODE_QUALITY="insider"
      ;;
    *)
      ;;
  esac
done

URL=$( curl -s "https://update.code.visualstudio.com/api/update/win32-x64-archive/${VSCODE_QUALITY}/0000000000000000000000000000000000000000" | jq -c '.url' | sed -E 's/.*"([^"]+)".*/\1/' )
# echo "url: ${URL}"
FILE="${URL##*/}"
# echo "file: ${FILE}"
DIRECTORY="${FILE%.zip}"
# echo "directory: ${DIRECTORY}"

if [[ ! -f "${FILE}" ]]; then
  wget "${URL}"
fi

if [[ ! -d "${DIRECTORY}" ]]; then
  unzip "${FILE}" -d "${DIRECTORY}"
fi

if [[ "${VSCODE_QUALITY}" == "insider" ]]; then
  DLL_PATH=$(find "${DIRECTORY}" -type f -name "code-insiders")
else
  DLL_PATH=$(find "${DIRECTORY}" -type f -name "code")
fi

LINE="$( grep -E '^[[:space:]]*(export[[:space:]]+)?VERSIONFOLDER[[:space:]]*=' "$DLL_PATH" | tail -n1 )"

VERSIONFOLDER="${LINE#*=}"
VERSIONFOLDER="${VERSIONFOLDER#\"}"
VERSIONFOLDER="${VERSIONFOLDER%\"}"

APIS=$( jq -r '.extensionEnabledApiProposals' "${DIRECTORY}/${VERSIONFOLDER}/resources/app/product.json" )
APIS=$( echo "${APIS}" | jq '. += {"jeanp413.open-remote-ssh": ["resolvers", "tunnels", "terminalDataWriteEvent", "contribRemoteHelp", "contribViewsRemote"]}' )
APIS=$( echo "${APIS}" | jq '. += {"jeanp413.open-remote-wsl": ["resolvers", "contribRemoteHelp", "contribViewsRemote"]}' )
echo "$( jq --argjson v "${APIS}" 'setpath(["extensionEnabledApiProposals"]; $v)' product.json )" > product.json

APIS=$( jq -r '.extensionsEnabledWithApiProposalVersion' "${DIRECTORY}/${VERSIONFOLDER}/resources/app/product.json" )
echo "$( jq --argjson v "${APIS}" 'setpath(["extensionsEnabledWithApiProposalVersion"]; $v)' product.json )" > product.json
